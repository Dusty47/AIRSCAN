figlet -f emboss2 "installing  dependencies"

apt update

apt upgrade

apt install aircrack-ng

apt install figlet


figlet -f emboss2 "AIRSCAN version 1.0"






figlet -f emboss2 "STARTING AIRCRACK"
figlet -f emboss2 "SETTING UP"
figlet -f slant "CHECKING STATUS"
figlet -f emboss2 "date"
date




airmon-ng start wlx00c0ca97e839

airodump-ng wlan0mon






















































airmon-ng stop wlan0mon

figlet  -f emboss2 "the  scan is complete"





































